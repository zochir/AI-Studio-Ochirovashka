# AI News Studio — Android wrapper prototype 0.2

This project wraps the HTML editor in a native Android WebView and exposes Android's `TextToSpeech` engine through a JavaScript bridge. It addresses browsers that do not implement the Web Speech API.

## What works in this prototype
- Native Android TextToSpeech for previewing text, using voices installed in Android's TTS engine.
- Voice list exposed to the editor; prefers Russian voices when available.
- Adjustable speech rate and stop button.
- Existing editor fields, avatar photo preview, captions and JSON project settings.

## Important limits
- This is Android Studio source code, **not a prebuilt APK**.
- TextToSpeech availability and offline operation depend on the speech engine and voice packs installed on the phone. In Android Settings, configure Text-to-speech output and download a Russian voice pack if available.
- This does not yet synthesize an audio file or generate a talking-head video. A real local avatar engine and MP4 renderer remain separate work.
- Voice choices are device-installed voices; interchangeable neural voice packs will need a separate `VoiceEngine` adapter later.

## Build
Open this folder in Android Studio with Android SDK 35 and JDK 17 available, then build the `app` debug variant. No microphone permission is required for TextToSpeech preview.
