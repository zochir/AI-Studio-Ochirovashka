plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.ainewsstudio.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.ainewsstudio.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2-native-tts"
    }
}
